package sample;
/**
 *Class Inventory.java
 */
import javafx.collections.ObservableList;
import static javafx.collections.FXCollections.observableArrayList;


public class Inventory {
    private static ObservableList<Part> allParts = observableArrayList();
    private static ObservableList<Product> allProducts = observableArrayList();
    private static int newPartId = 1010000;
    private static int newProductId = 9010000;

    /**
     *
     * @param newPart Part to be added to inventory.
     */

    public static void addPart(Part newPart){
        allParts.add(newPart);
    }

    /**
     *
     * @param newProduct Product to be added to inventory.
     */

    public static void addProduct(Product newProduct){

        allProducts.add(newProduct);
    }

    /**
     *
     * @return The new part Id.
     */

    public static int getNewPartId(){
        return newPartId;
    }

    /**
     * Increments newPartId.
     */

    public static void incrementNewPartId(){
        newPartId++;
    }

    /**
     *
     * @return The new product Id.
     */

    public static int getNewProductId(){
        return newProductId;
    }

    /**
     * Increments newProductId.
     */

    public static void incrementNewProductId(){
        newProductId++;
    }

    /**
     * Depreciated. Search functionality added without use of this function.
     * @param partId Part Id to be searched.
     * @return Part that matched the Part Id passed to the method.
     */

    public static Part lookupPart(int partId) {
        return null;
    }

    /**
     * Depreciated. Search functionality added without use of this function.
     * @param productId Product Id to be searched.
     * @return Product that matched the Product Id passed to the method.
     */

    public static Product lookupProduct(int productId) {
        return null;
    }

    /**
     * Depreciated. Search functionality added without use of this function.
     * @param partName Part name to be searched.
     * @return Part that matched the part name passed to the method.
     */

    public static Part lookupPart(String partName) {
        return null;
    }

    /**
     * Depreciated. Search functionality added without use of this function.
     * @param productName Product name to be searched.
     * @return Product that matched the product name passed to the method.
     */

    public static Product lookupProduct(String productName) {
        return null;
    }

    /**
     * Takes the index of a part and replaces it with the selected part. I originally attempted to use a for loop to cycle through all parts in inventory, then update the one that had the same unique part id.
     * The problem would occur whenever a part would need to change from InHouse to Outsourced, or vice versa. I came up with this delete and replace method for simplicity, as the order of the list does not
     * matter. I used this same technique for the updateProduct method.
     * @param index Part to be removed.
     * @param selectedPart Part to be added.
     */

    public static void updatePart(int index, Part selectedPart){
        getAllParts().remove(index);
        addPart(selectedPart);
    }

    /**
     * Takes the index of a product and replaces it with the selected product.
     * @param index Product to be removed.
     * @param newProduct Product to be added.
     */

    public static void updateProduct(int index, Product newProduct){
        getAllProducts().remove(index);
        addProduct(newProduct);
    }

    /**
     * Takes the part passed and removes the corresponding part in the allParts list.
     * @param selectedPart Part to be deleted.
     * @return True if successful.
     */

    public static boolean deletePart(Part selectedPart){
        int i;
        for (i = 0; i<allParts.size(); i++){
            if (selectedPart.getId() == allParts.get(i).getId()){
                allParts.remove(i);
                return true;
            }
        }
        return false;
    }

    /**
     * Takes the product passed and removes the corresponding product in the allProducts list.
     * @param selectedProduct Product to be deleted.
     * @return True if successful.
     */

    public static boolean deleteProduct(Product selectedProduct){
        int i;
        for (i = 0; i<allProducts.size(); i++){
            if (selectedProduct.equals(allProducts.get(i))){
                allProducts.remove(i);
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @return allParts.
     */

    public static ObservableList<Part> getAllParts(){
        return allParts;
    }

    /**
     *
     * @return allProducts.
     */

    public static ObservableList<Product> getAllProducts(){
        return allProducts;
    }
}
