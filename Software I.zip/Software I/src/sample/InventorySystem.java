package sample;
/**
 * InventorySystem.java
 * @author James Kinder
 * Software I
 * Student ID: 001481730
 * In the next version of this software, I would implement a system of buttons and textfields on the main form to add and subtract stock from the selected inventory item. In an inventory/warehouse environment, the most common modification to be done to an inventory item is the
 * change in inventory level. This would replace the inventory stock level in the modify part/product forms, and stock values would be initialized to 0 automatically.
 */

import javafx.application.Application;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.util.concurrent.atomic.AtomicInteger;
import static javafx.collections.FXCollections.observableArrayList;

public class InventorySystem extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    /**
     *The GUI interface by which the inventory model can be accessed by the user.
     * @param primaryStage the stage to start.
     */

    @Override
    public void start(Stage primaryStage) {
        Scene mainForm, addPartForm, modifyPartForm, addProductForm, modifyProductForm;

        //mainForm
        Label errorLabel = new Label("");
        errorLabel.getStyleClass().add("label-red");
        Label title = new Label("Inventory Management System");
        title.getStyleClass().add("label-title");
        title.setAlignment(Pos.TOP_LEFT);
        HBox titleAndErrorLabels = new HBox(title, errorLabel);
        TableView<Part> inventoryParts = new TableView<Part>(Inventory.getAllParts());
        TableColumn<Part, Integer> partIdColumn = new TableColumn<Part, Integer>("Part ID");
        partIdColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getId()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, String> partNameColumn = new TableColumn<Part, String>("Part Name");
        partNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Part, String> p) {
                ObservableValue<String> observableValue = new SimpleStringProperty(p.getValue().getName());
                return observableValue;
            }
        });
        TableColumn<Part, Integer> partInventoryLevelColumn = new TableColumn<Part, Integer>("Inventory Level");
        partInventoryLevelColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getStock()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, Double> partPriceCostColumn = new TableColumn<Part, Double>("Price/Cost per Unit");
        partPriceCostColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Double>, ObservableValue<Double>>() {
            public ObservableValue<Double> call(TableColumn.CellDataFeatures<Part, Double> p) {
                ObservableValue<Double> observableValue = new SimpleDoubleProperty(p.getValue().getPrice()).asObject();
                return observableValue;
            }
        });
        inventoryParts.getColumns().setAll(partIdColumn, partNameColumn, partInventoryLevelColumn, partPriceCostColumn);
        Label parts = new Label("Parts");
        TextField partsSearch = new TextField("Search by Part ID or Name");
        FilteredList<Part> searchedParts = new FilteredList<>(Inventory.getAllParts(), p -> true);
        partsSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            searchedParts.setPredicate(searchedForPart -> {
                if(newValue == null || newValue.isEmpty()){
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if(searchedForPart.getName().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }
                else if(Integer.toString(searchedForPart.getId()).contains(lowerCaseFilter)){
                    return true;
                }
                return false;
            });
        });
        SortedList<Part> sortedInventoryParts = new SortedList<>(searchedParts);
        if (searchedParts.isEmpty() && !inventoryParts.getItems().isEmpty()){
            errorLabel.setText("Error: part not found. Please use different search criteria.");
        }
        sortedInventoryParts.comparatorProperty().bind(inventoryParts.comparatorProperty());
        inventoryParts.setItems(sortedInventoryParts);
        Button partAdd = new Button("Add");
        Button partModify = new Button("Modify");
        Button partDelete = new Button("Delete");
        partDelete.setOnAction(e->{
            Button yes = new Button("Yes");
            Button no = new Button("No");
            Label confirmationMessage = new Label("Are you sure you want to delete?");
            HBox yesNo = new HBox(yes, no);
            VBox confirmationQuestion = new VBox(confirmationMessage, yesNo);
            Scene popUp = new Scene(confirmationQuestion);
            Stage confirmation = new Stage();
            confirmation.setScene(popUp);
            confirmation.show();
            yes.setOnAction(f->{
                if(!Inventory.deletePart(inventoryParts.getSelectionModel().getSelectedItem())) {
                    errorLabel.setText("Error: part not deleted. Please make a valid selection");
                }
                confirmation.close();
            });
            no.setOnAction(f -> confirmation.close());
        });
        HBox titleAndSearch = new HBox(10, parts, partsSearch);
        HBox partsButtons = new HBox(5, partAdd, partModify, partDelete);
        VBox partsPane = new VBox(5, titleAndSearch, inventoryParts, partsButtons);
        TableView<Product> inventoryProducts = new TableView<Product>(Inventory.getAllProducts());
        TableColumn<Product, Integer> productIdColumn = new TableColumn<Product, Integer>("Product ID");
        productIdColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Product, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Product, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getId()).asObject();
                return observableValue;
            }
        });
        TableColumn<Product, String> productNameColumn = new TableColumn<Product, String>("Product Name");
        productNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Product, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Product, String> p) {
                ObservableValue<String> observableValue = new SimpleStringProperty(p.getValue().getName());
                return observableValue;
            }
        });
        TableColumn<Product, Integer> productInventoryLevelColumn = new TableColumn<Product, Integer>("Inventory Level");
        productInventoryLevelColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Product, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Product, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getStock()).asObject();
                return observableValue;
            }
        });
        TableColumn<Product, Double> productPriceCostColumn = new TableColumn<Product, Double>("Price/Cost per Unit");
        productPriceCostColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Product, Double>, ObservableValue<Double>>() {
            public ObservableValue<Double> call(TableColumn.CellDataFeatures<Product, Double> p) {
                ObservableValue<Double> observableValue = new SimpleDoubleProperty(p.getValue().getPrice()).asObject();
                return observableValue;
            }
        });
        inventoryProducts.getColumns().setAll(productIdColumn, productNameColumn, productInventoryLevelColumn, productPriceCostColumn);
        Label products = new Label("Products");
        TextField productsSearch = new TextField("Search by Product ID or Product Name");
        FilteredList<Product> searchedProducts = new FilteredList<>(Inventory.getAllProducts(), p -> true);
        productsSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            searchedProducts.setPredicate(searchedForProduct -> {
                if(newValue == null || newValue.isEmpty()){
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if(searchedForProduct.getName().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }
                else if(Integer.toString(searchedForProduct.getId()).contains(lowerCaseFilter)){
                    return true;
                }
                return false;
            });
        });
        SortedList<Product> sortedInventoryProducts = new SortedList<>(searchedProducts);
        sortedInventoryProducts.comparatorProperty().bind(inventoryProducts.comparatorProperty());
        inventoryProducts.setItems(sortedInventoryProducts);
        Button productAdd = new Button("Add");
        Button productModify = new Button("Modify");
        Button productDelete = new Button("Delete");
        productDelete.setOnAction(e->{
            Button yes = new Button("Yes");
            Button no = new Button("No");
            Label confirmationMessage = new Label("Are you sure you want to delete?");
            HBox yesNo = new HBox(5, yes, no);
            VBox confirmationQuestion = new VBox(10, confirmationMessage, yesNo);
            Scene popUp = new Scene(confirmationQuestion);
            popUp.getStylesheets().add("sample/Stylesheets.css");
            Stage confirmation = new Stage();
            confirmation.setScene(popUp);
            confirmation.show();
            yes.setOnAction(f->{
                if(inventoryProducts.getSelectionModel().getSelectedItem().getAllAssociatedParts().isEmpty()) {
                    if (!Inventory.deleteProduct(inventoryProducts.getSelectionModel().getSelectedItem())) {
                        errorLabel.setText("Error: product not deleted. Make sure a valid product is selected.");
                    }
                }
                else{
                    errorLabel.setText("Error: product to be deleted cannot have associated parts.");
                }
                confirmation.close();
            });
            no.setOnAction(f -> confirmation.close());
        });
        HBox pTitleAndSearch = new HBox(10, products, productsSearch);
        HBox productsButtons = new HBox(5, productAdd, productModify, productDelete);
        Button exit = new Button("Exit");
        VBox productsPane = new VBox(5, pTitleAndSearch, inventoryProducts, productsButtons);
        HBox inventoryLists = new HBox(20, partsPane, productsPane);
        VBox mainWindow = new VBox(titleAndErrorLabels, inventoryLists, exit);
        mainForm = new Scene(mainWindow);
        mainForm.getStylesheets().add("sample/Stylesheets.css");

        //addPartForm
        Label errorLabelAddPartForm = new Label("");
        errorLabelAddPartForm.getStyleClass().add("label-red");
        Label addPart = new Label("Add Part");
        addPart.getStyleClass().add("label-title");
        Label idLabel = new Label("ID");
        Label nameLabel = new Label("Name");
        Label invLabel = new Label("Inv");
        Label priceCostLabel = new Label("Price/Cost");
        Label maxLabel = new Label("Max");
        Label minLabel = new Label("Min");
        Label machineIdOrCompanyNameLabel = new Label("Machine ID");
        TextField idTextField = new TextField();
        idTextField.setEditable(false);
        TextField nameTextField = new TextField();
        TextField invTextField = new TextField();
        TextField priceCostTextField = new TextField();
        TextField maxTextField = new TextField();
        TextField minTextField = new TextField();
        TextField machineIdOrCompanyNameTextField = new TextField();
        RadioButton inHouse = new RadioButton("In-House");
        RadioButton outsourced = new RadioButton("Outsourced");
        ToggleGroup source = new ToggleGroup();
        inHouse.setToggleGroup(source);
        inHouse.setSelected(true);
        outsourced.setToggleGroup(source);
        outsourced.setOnAction(e->machineIdOrCompanyNameLabel.setText("Company Name"));
        inHouse.setOnAction(e-> machineIdOrCompanyNameLabel.setText("Machine ID"));
        HBox titleAndRadioButtons = new HBox(addPart, inHouse, outsourced, errorLabelAddPartForm);
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");
        HBox saveCancelButtons = new HBox(saveButton, cancelButton);
        GridPane addPartTextFields = new GridPane();
        addPartTextFields.addColumn(0, idLabel, nameLabel, invLabel, priceCostLabel, maxLabel, machineIdOrCompanyNameLabel);
        addPartTextFields.addColumn(1, idTextField, nameTextField, invTextField, priceCostTextField, maxTextField, machineIdOrCompanyNameTextField);
        addPartTextFields.add(minLabel, 2, 4);
        addPartTextFields.add(minTextField, 3, 4);
        addPartTextFields.setHgap(30.0);
        addPartTextFields.setVgap(10.0);
        VBox addPartsWindow = new VBox(20, titleAndRadioButtons, addPartTextFields, saveCancelButtons);
        addPartForm = new Scene(addPartsWindow);
        addPartForm.getStylesheets().add("sample/Stylesheets.css");

        //modifyPartForm
        Label errorLabelModifyPartForm = new Label("");
        errorLabelModifyPartForm.getStyleClass().add("label-red");
        Label modifyPart = new Label("Modify Part");
        modifyPart.getStyleClass().add("label-title");
        Label idLabelMod = new Label("ID");
        Label nameLabelMod = new Label("Name");
        Label invLabelMod = new Label("Inv");
        Label priceCostLabelMod = new Label("Price/Cost");
        Label maxLabelMod = new Label("Max");
        Label minLabelMod = new Label("Min");
        Label machineIdOrCompanyNameLabelMod = new Label("Machine ID");
        TextField idTextFieldMod = new TextField();
        if(inventoryParts.getSelectionModel().getSelectedItem() != null){
            idTextFieldMod.setText(Integer.toString(inventoryParts.getSelectionModel().getSelectedItem().getId()));
        }
        idTextFieldMod.setEditable(false);
        TextField nameTextFieldMod = new TextField();
        TextField invTextFieldMod = new TextField();
        TextField priceCostTextFieldMod = new TextField();
        TextField maxTextFieldMod = new TextField();
        TextField minTextFieldMod = new TextField();
        TextField machineIdOrCompanyNameTextFieldMod = new TextField();
        RadioButton inHouseMod = new RadioButton("In-House");
        RadioButton outsourcedMod = new RadioButton("Outsourced");
        ToggleGroup sourceMod = new ToggleGroup();
        inHouseMod.setToggleGroup(sourceMod);
        inHouseMod.setSelected(true);
        outsourcedMod.setToggleGroup(sourceMod);
        outsourcedMod.setOnAction(e->machineIdOrCompanyNameLabelMod.setText("Company Name"));
        inHouseMod.setOnAction(e-> machineIdOrCompanyNameLabelMod.setText("Machine ID"));
        HBox titleAndRadioButtonsMod = new HBox(modifyPart, inHouseMod, outsourcedMod, errorLabelModifyPartForm);
        Button saveButtonMod = new Button("Save");
        Button cancelButtonMod = new Button("Cancel");
        HBox saveCancelButtonsMod = new HBox(saveButtonMod, cancelButtonMod);
        GridPane addPartTextFieldsMod = new GridPane();
        addPartTextFieldsMod.addColumn(0, idLabelMod, nameLabelMod, invLabelMod, priceCostLabelMod, maxLabelMod, machineIdOrCompanyNameLabelMod);
        addPartTextFieldsMod.addColumn(1, idTextFieldMod, nameTextFieldMod, invTextFieldMod, priceCostTextFieldMod, maxTextFieldMod, machineIdOrCompanyNameTextFieldMod);
        addPartTextFieldsMod.add(minLabelMod, 2, 4);
        addPartTextFieldsMod.add(minTextFieldMod, 3, 4);
        addPartTextFieldsMod.setHgap(30.0);
        addPartTextFieldsMod.setVgap(10.0);
        VBox addPartsWindowMod = new VBox(20, titleAndRadioButtonsMod, addPartTextFieldsMod, saveCancelButtonsMod);
        modifyPartForm = new Scene(addPartsWindowMod);
        modifyPartForm.getStylesheets().add("sample/Stylesheets.css");

        //addProductForm
        Label errorLabelAddProductForm = new Label("");
        errorLabelAddProductForm.getStyleClass().add("label-red");
        Label addProductLabel = new Label("Add Product");
        addProductLabel.getStyleClass().add("label-title");
        TextField searchAllPartsDataTextField = new TextField("Search by Part ID or Name");
        Label idLabelProduct = new Label("ID");
        Label nameLabelProduct = new Label("Name");
        Label invLabelProduct = new Label("Inv");
        Label priceCostLabelProduct = new Label("Price/Cost");
        Label maxLabelProduct = new Label("Max");
        Label minLabelProduct = new Label("Min");
        TextField idTextFieldProduct = new TextField(Integer.toString(Inventory.getNewProductId()));
        idTextFieldProduct.setEditable(false);
        TextField nameTextFieldProduct = new TextField();
        TextField invTextFieldProduct = new TextField();
        TextField priceCostTextFieldProduct = new TextField();
        TextField maxTextFieldProduct = new TextField();
        TextField minTextFieldProduct = new TextField();
        GridPane newProductTextFields = new GridPane();
        newProductTextFields.addColumn(0, idLabelProduct, nameLabelProduct, invLabelProduct, priceCostLabelProduct, maxLabelProduct);
        newProductTextFields.addColumn(1, idTextFieldProduct, nameTextFieldProduct, invTextFieldProduct, priceCostTextFieldProduct, maxTextFieldProduct);
        newProductTextFields.add(minLabelProduct, 2, 4);
        newProductTextFields.add(minTextFieldProduct, 3, 4);
        newProductTextFields.setHgap(30.0);
        newProductTextFields.setVgap(10.0);
        TableView<Part> allPartData = new TableView<>(Inventory.getAllParts());
        TableColumn<Part, Integer> allPartDataIdColumn = new TableColumn<Part, Integer>("Part ID");
        allPartDataIdColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getId()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, String> allPartDataNameColumn = new TableColumn<Part, String>("Part Name");
        allPartDataNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Part, String> p) {
                ObservableValue<String> observableValue = new SimpleStringProperty(p.getValue().getName());
                return observableValue;
            }
        });
        TableColumn<Part, Integer> allPartDataInventoryLevelColumn = new TableColumn<Part, Integer>("Inventory Level");
        allPartDataInventoryLevelColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getStock()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, Double> allPartDataPriceCostColumn = new TableColumn<Part, Double>("Price/Cost per Unit");
        allPartDataPriceCostColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Double>, ObservableValue<Double>>() {
            public ObservableValue<Double> call(TableColumn.CellDataFeatures<Part, Double> p) {
                ObservableValue<Double> observableValue = new SimpleDoubleProperty(p.getValue().getPrice()).asObject();
                return observableValue;
            }
        });
        allPartData.getColumns().setAll(allPartDataIdColumn, allPartDataNameColumn, allPartDataInventoryLevelColumn, allPartDataPriceCostColumn);
        FilteredList<Part> allPartsDataSearch = new FilteredList<>(Inventory.getAllParts(), p -> true);
        searchAllPartsDataTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            allPartsDataSearch.setPredicate(searchedForPart -> {
                if(newValue == null || newValue.isEmpty()){
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if(searchedForPart.getName().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }
                else if(Integer.toString(searchedForPart.getId()).contains(lowerCaseFilter)){
                    return true;
                }
                return false;
            });
        });
        SortedList<Part> sortedAllPartsData = new SortedList<>(allPartsDataSearch);
        sortedAllPartsData.comparatorProperty().bind(allPartData.comparatorProperty());
        allPartData.setItems(sortedAllPartsData);
        Button addButton = new Button("Add");
        TableView<Part> associatedParts = new TableView<>();
        ObservableList<Part> associatedPartsList = observableArrayList();
        TableColumn<Part, Integer> associatedPartIdColumn = new TableColumn<Part, Integer>("Part ID");
        associatedPartIdColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getId()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, String> associatedPartNameColumn = new TableColumn<Part, String>("Part Name");
        associatedPartNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Part, String> p) {
                ObservableValue<String> observableValue = new SimpleStringProperty(p.getValue().getName());
                return observableValue;
            }
        });
        TableColumn<Part, Integer> associatedPartInventoryLevelColumn = new TableColumn<Part, Integer>("Inventory Level");
        associatedPartInventoryLevelColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getStock()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, Double> associatedPartPriceCostColumn = new TableColumn<Part, Double>("Price/Cost per Unit");
        associatedPartPriceCostColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Double>, ObservableValue<Double>>() {
            public ObservableValue<Double> call(TableColumn.CellDataFeatures<Part, Double> p) {
                ObservableValue<Double> observableValue = new SimpleDoubleProperty(p.getValue().getPrice()).asObject();
                return observableValue;
            }
        });
        associatedParts.getColumns().setAll(associatedPartIdColumn, associatedPartNameColumn, associatedPartInventoryLevelColumn, associatedPartPriceCostColumn);
        addButton.setOnAction(e->{
            associatedPartsList.add(allPartData.getSelectionModel().getSelectedItem());
            associatedParts.getItems().setAll(associatedPartsList);
        });
        Button removeAssociatedPart = new Button("Remove Associated Part");
        removeAssociatedPart.setOnAction(e->{
            Button yes = new Button("Yes");
            Button no = new Button("No");
            Label confirmation = new Label("Are you sure you want to remove associated part?");
            HBox yesNo = new HBox(yes, no);
            VBox popUp = new VBox(confirmation, yesNo);
            Scene confirmationWindow = new Scene(popUp);
            Stage popUpWindow = new Stage();
            popUpWindow.setScene(confirmationWindow);
            popUpWindow.show();
            yes.setOnAction(f -> {
                associatedPartsList.remove(associatedParts.getSelectionModel().getSelectedItem());
                associatedParts.getItems().setAll(associatedPartsList);
                popUpWindow.close();
            });
            no.setOnAction(f -> popUpWindow.close());
        });
        Button saveNewProduct = new Button("Save");
        Button cancelNewProduct = new Button("Cancel");
        HBox saveAndCancelNewProduct = new HBox(saveNewProduct, cancelNewProduct);
        VBox addProductRightSide = new VBox(searchAllPartsDataTextField, allPartData, addButton, associatedParts, removeAssociatedPart, saveAndCancelNewProduct);
        VBox addProductLeftSide = new VBox(addProductLabel, newProductTextFields, errorLabelAddProductForm);
        HBox addProductWindow = new HBox(addProductLeftSide, addProductRightSide);
        addProductForm = new Scene(addProductWindow);
        addProductForm.getStylesheets().add("sample/Stylesheets.css");

        //modifyProductForm
        Label errorLabelModifyProductForm = new Label("");
        errorLabelModifyProductForm.getStyleClass().add("label-red");
        Label modifyProductLabel = new Label("Modify Product");
        modifyProductLabel.getStyleClass().add("label-title");
        TextField searchAllPartsDataTextFieldMod = new TextField("Search by Part ID or Name");
        Label idLabelProductMod = new Label("ID");
        Label nameLabelProductMod = new Label("Name");
        Label invLabelProductMod = new Label("Inv");
        Label priceCostLabelProductMod = new Label("Price/Cost");
        Label maxLabelProductMod = new Label("Max");
        Label minLabelProductMod = new Label("Min");
        TextField idTextFieldProductMod = new TextField();
        if(inventoryProducts.getSelectionModel().getSelectedItem() != null){
            idTextFieldProductMod.setText(Integer.toString(inventoryProducts.getSelectionModel().getSelectedItem().getId()));
        }
        idTextFieldProductMod.setEditable(false);
        TextField nameTextFieldProductMod = new TextField();
        TextField invTextFieldProductMod = new TextField();
        TextField priceCostTextFieldProductMod = new TextField();
        TextField maxTextFieldProductMod = new TextField();
        TextField minTextFieldProductMod = new TextField();
        GridPane newProductTextFieldsMod = new GridPane();
        newProductTextFieldsMod.addColumn(0, idLabelProductMod, nameLabelProductMod, invLabelProductMod, priceCostLabelProductMod, maxLabelProductMod);
        newProductTextFieldsMod.addColumn(1, idTextFieldProductMod, nameTextFieldProductMod, invTextFieldProductMod, priceCostTextFieldProductMod, maxTextFieldProductMod);
        newProductTextFieldsMod.add(minLabelProductMod, 2, 4);
        newProductTextFieldsMod.add(minTextFieldProductMod, 3, 4);
        newProductTextFieldsMod.setHgap(30.0);
        newProductTextFieldsMod.setVgap(10.0);
        TableView<Part> allPartDataMod = new TableView<>(Inventory.getAllParts());
        TableColumn<Part, Integer> allPartDataIdColumnMod = new TableColumn<Part, Integer>("Part ID");
        allPartDataIdColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getId()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, String> allPartDataNameColumnMod = new TableColumn<Part, String>("Part Name");
        allPartDataNameColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Part, String> p) {
                ObservableValue<String> observableValue = new SimpleStringProperty(p.getValue().getName());
                return observableValue;
            }
        });
        TableColumn<Part, Integer> allPartDataInventoryLevelColumnMod = new TableColumn<Part, Integer>("Inventory Level");
        allPartDataInventoryLevelColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getStock()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, Double> allPartDataPriceCostColumnMod = new TableColumn<Part, Double>("Price/Cost per Unit");
        allPartDataPriceCostColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Double>, ObservableValue<Double>>() {
            public ObservableValue<Double> call(TableColumn.CellDataFeatures<Part, Double> p) {
                ObservableValue<Double> observableValue = new SimpleDoubleProperty(p.getValue().getPrice()).asObject();
                return observableValue;
            }
        });
        allPartDataMod.getColumns().setAll(allPartDataIdColumnMod, allPartDataNameColumnMod, allPartDataInventoryLevelColumnMod, allPartDataPriceCostColumnMod);
        FilteredList<Part> allPartsDataSearchMod = new FilteredList<>(Inventory.getAllParts(), p -> true);
        searchAllPartsDataTextFieldMod.textProperty().addListener((observable, oldValue, newValue) -> {
            allPartsDataSearchMod.setPredicate(searchedForPart -> {
                if(newValue == null || newValue.isEmpty()){
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if(searchedForPart.getName().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }
                else if(Integer.toString(searchedForPart.getId()).contains(lowerCaseFilter)){
                    return true;
                }
                return false;
            });
        });
        SortedList<Part> sortedAllPartsDataMod = new SortedList<>(allPartsDataSearchMod);
        sortedAllPartsDataMod.comparatorProperty().bind(allPartDataMod.comparatorProperty());
        allPartDataMod.setItems(sortedAllPartsDataMod);
        Button addButtonMod = new Button("Add");
        TableView<Part> associatedPartsMod = new TableView<>();
        ObservableList<Part> associatedPartsListMod = observableArrayList();
        int j;
        for(j = 0; j<Inventory.getAllProducts().size(); j++){
            if(Inventory.getAllProducts().get(j).getId() == Integer.parseInt(idTextFieldProductMod.getText())){
                associatedPartsListMod.setAll(Inventory.getAllProducts().get(j).getAllAssociatedParts());
            }
        }
        associatedPartsMod.setItems(associatedPartsListMod);
        AtomicInteger productIndex = new AtomicInteger();
        TableColumn<Part, Integer> associatedPartIdColumnMod = new TableColumn<Part, Integer>("Part ID");
        associatedPartIdColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getId()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, String> associatedPartNameColumnMod = new TableColumn<Part, String>("Part Name");
        associatedPartNameColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Part, String> p) {
                ObservableValue<String> observableValue = new SimpleStringProperty(p.getValue().getName());
                return observableValue;
            }
        });
        TableColumn<Part, Integer> associatedPartInventoryLevelColumnMod = new TableColumn<Part, Integer>("Inventory Level");
        associatedPartInventoryLevelColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Integer>, ObservableValue<Integer>>() {
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<Part, Integer> p) {
                ObservableValue<Integer> observableValue = new SimpleIntegerProperty(p.getValue().getStock()).asObject();
                return observableValue;
            }
        });
        TableColumn<Part, Double> associatedPartPriceCostColumnMod = new TableColumn<Part, Double>("Price/Cost per Unit");
        associatedPartPriceCostColumnMod.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Part, Double>, ObservableValue<Double>>() {
            public ObservableValue<Double> call(TableColumn.CellDataFeatures<Part, Double> p) {
                ObservableValue<Double> observableValue = new SimpleDoubleProperty(p.getValue().getPrice()).asObject();
                return observableValue;
            }
        });
        associatedPartsMod.getColumns().setAll(associatedPartIdColumnMod, associatedPartNameColumnMod, associatedPartInventoryLevelColumnMod, associatedPartPriceCostColumnMod);
        int finalJ = j;
        addButtonMod.setOnAction(e->Inventory.getAllProducts().get(finalJ).addAssociatedPart(associatedPartsMod.getSelectionModel().getSelectedItem()));
        Button removeAssociatedPartMod = new Button("Remove Associated Part");
        removeAssociatedPartMod.setOnAction(e->{
            Button yes = new Button("Yes");
            Button no = new Button("No");
            Label confirmation = new Label("Are you sure you want to remove associated part?");
            HBox yesNo = new HBox(yes, no);
            VBox popUp = new VBox(confirmation, yesNo);
            Scene confirmationWindow = new Scene(popUp);
            Stage popUpWindow = new Stage();
            popUpWindow.setScene(confirmationWindow);
            popUpWindow.show();
            yes.setOnAction(f -> {
                Product modifiedProduct = inventoryProducts.getSelectionModel().getSelectedItem();
                modifiedProduct.deleteAssociatedPart(associatedPartsMod.getSelectionModel().getSelectedItem());
                associatedPartsMod.setItems(modifiedProduct.getAllAssociatedParts());
                popUpWindow.close();
            });
            no.setOnAction(f -> popUpWindow.close());
        });
        Button saveNewProductMod = new Button("Save");
        Button cancelNewProductMod = new Button("Cancel");
        HBox saveAndCancelNewProductMod = new HBox(saveNewProductMod, cancelNewProductMod);
        VBox modifyProductRightSide = new VBox(searchAllPartsDataTextFieldMod, allPartDataMod, addButtonMod, associatedPartsMod, removeAssociatedPartMod, saveAndCancelNewProductMod);
        VBox modifyProductLeftSide = new VBox(modifyProductLabel, newProductTextFieldsMod, errorLabelModifyProductForm);
        HBox modifyProductWindow = new HBox(modifyProductLeftSide, modifyProductRightSide);
        modifyProductForm = new Scene(modifyProductWindow);
        modifyProductForm.getStylesheets().add("sample/Stylesheets.css");


        //Scene change event handlers and exception handlers
        //Main form
        partAdd.setOnAction(e ->{
            primaryStage.setScene(addPartForm);
            Inventory.incrementNewPartId();
            idTextField.setText(Integer.toString(Inventory.getNewPartId()));
            nameTextField.setText("");
            invTextField.setText("");
            priceCostTextField.setText("");
            maxTextField.setText("");
            minTextField.setText("");
            machineIdOrCompanyNameTextField.setText("");
        });
        partModify.setOnAction(e -> {
            try {
                Part partToModify = inventoryParts.getSelectionModel().getSelectedItem();
                primaryStage.setScene(modifyPartForm);
                idTextFieldMod.setText(Integer.toString(partToModify.getId()));
                nameTextFieldMod.setText(partToModify.getName());
                invTextFieldMod.setText(Integer.toString(partToModify.getStock()));
                priceCostTextFieldMod.setText(Double.toString(partToModify.getPrice()));
                maxTextFieldMod.setText(Integer.toString(partToModify.getMax()));
                minTextFieldMod.setText(Integer.toString(partToModify.getMin()));
                if (partToModify.getClass() == InHouse.class) {
                    machineIdOrCompanyNameTextFieldMod.setText(Integer.toString(((InHouse) partToModify).getMachineId()));
                }
            else{
                machineIdOrCompanyNameTextFieldMod.setText(((Outsourced) partToModify).getCompanyName());
                inHouseMod.setSelected(false);
                outsourcedMod.setSelected(true);
                machineIdOrCompanyNameLabelMod.setText("Company Name");
            }
            }
            catch (NullPointerException exception){
                errorLabel.setText("Error: please select a part to modify.");
                primaryStage.setScene(mainForm);
            }
        });
        productAdd.setOnAction(e -> {
            Inventory.incrementNewProductId();
            idTextFieldProduct.setText(Integer.toString(Inventory.getNewProductId()));
            nameTextFieldProduct.setText("");
            invTextFieldProduct.setText("");
            priceCostTextFieldProduct.setText("");
            maxTextFieldProduct.setText("");
            minTextFieldProduct.setText("");
            primaryStage.setScene(addProductForm);
        });
        productModify.setOnAction(e ->{
            try {
                Product productToModify = inventoryProducts.getSelectionModel().getSelectedItem();
                primaryStage.setScene(modifyProductForm);
                int i;
                for (i = 0; i < Inventory.getAllProducts().size(); i++) {
                    if (productToModify.getId() == Inventory.getAllProducts().get(i).getId()) {
                        productIndex.set(i);
                    }
                }
                idTextFieldProductMod.setText(Integer.toString(productToModify.getId()));
                nameTextFieldProductMod.setText(productToModify.getName());
                invTextFieldProductMod.setText(Integer.toString(productToModify.getStock()));
                priceCostTextFieldProductMod.setText(Double.toString(productToModify.getPrice()));
                maxTextFieldProductMod.setText(Integer.toString(productToModify.getMax()));
                minTextFieldProductMod.setText(Integer.toString(productToModify.getMin()));
                associatedPartsMod.setItems(productToModify.getAllAssociatedParts());
            }
            catch (NullPointerException exception){
                errorLabel.setText("Error: please select a product to modify.");
                primaryStage.setScene(mainForm);
            }
        });
        exit.setOnAction(e -> primaryStage.close());

        //Add part form
        saveButton.setOnAction(e->{
            try {
                if (Integer.parseInt(minTextField.getText()) > Integer.parseInt(maxTextField.getText())) {
                    errorLabelAddPartForm.setText("Error: the minimum stock cannot be set greater than the maximum stock.");
                } else if (Integer.parseInt(invTextField.getText()) < Integer.parseInt(minTextField.getText())) {
                    errorLabelAddPartForm.setText("Error: current inventory level cannot be lower than the minimum stock");
                } else if (Integer.parseInt(invTextField.getText()) > Integer.parseInt(maxTextField.getText())) {
                    errorLabelAddPartForm.setText("Error: current inventory level cannot be higher than the maximum stock");
                } else {
                    if (inHouse.isSelected()) {
                        InHouse newInHousePart = new InHouse(Integer.parseInt(machineIdOrCompanyNameTextField.getText()), Integer.parseInt(idTextField.getText()), nameTextField.getText(),
                                Double.parseDouble(priceCostTextField.getText()), Integer.parseInt(invTextField.getText()), Integer.parseInt(minTextField.getText()), Integer.parseInt(maxTextField.getText()));
                        Inventory.addPart(newInHousePart);
                    } else {
                        Outsourced newOutsourcedPart = new Outsourced(machineIdOrCompanyNameTextField.getText(), Integer.parseInt(idTextField.getText()), nameTextField.getText(),
                                Double.parseDouble(priceCostTextField.getText()), Integer.parseInt(invTextField.getText()), Integer.parseInt(minTextField.getText()), Integer.parseInt(maxTextField.getText()));
                        Inventory.addPart(newOutsourcedPart);
                    }
                    primaryStage.setScene(mainForm);
                }
            }
                catch (Exception exception){
                    errorLabelAddPartForm.setText("Error: input not valid. Try again.");
                };
        });
        cancelButton.setOnAction(e->primaryStage.setScene(mainForm));

        //Modify part form
        saveButtonMod.setOnAction(e->{
            try {
                if (Integer.parseInt(minTextFieldMod.getText()) > Integer.parseInt(maxTextFieldMod.getText())) {
                    errorLabelModifyPartForm.setText("Error: the minimum stock cannot be set greater than the maximum stock.");
                } else if (Integer.parseInt(invTextFieldMod.getText()) < Integer.parseInt(minTextFieldMod.getText())) {
                    errorLabelModifyPartForm.setText("Error: current inventory level cannot be lower than the minimum stock");
                } else if (Integer.parseInt(invTextFieldMod.getText()) > Integer.parseInt(maxTextFieldMod.getText())) {
                    errorLabelModifyPartForm.setText("Error: current inventory level cannot be higher than the maximum stock");
                } else {
                    if (inHouseMod.isSelected()) {
                        InHouse partToBeModifiedInHouse = new InHouse(Integer.parseInt(machineIdOrCompanyNameTextFieldMod.getText()), Integer.parseInt(idTextFieldMod.getText()), nameTextFieldMod.getText(), Double.parseDouble(priceCostTextFieldMod.getText()), Integer.parseInt(invTextFieldMod.getText()), Integer.parseInt(minTextFieldMod.getText()), Integer.parseInt(maxTextFieldMod.getText()));
                        int i;
                        for (i = 0; i < Inventory.getAllParts().size(); i++) {
                            if (partToBeModifiedInHouse.getId() == Inventory.getAllParts().get(i).getId()) {
                                Inventory.updatePart(i, partToBeModifiedInHouse);
                            }
                        }
                    } else {
                        Outsourced partToBeModifiedOutsourced = new Outsourced(machineIdOrCompanyNameTextFieldMod.getText(), Integer.parseInt(idTextFieldMod.getText()), nameTextFieldMod.getText(), Double.parseDouble(priceCostTextFieldMod.getText()), Integer.parseInt(invTextFieldMod.getText()), Integer.parseInt(minTextFieldMod.getText()), Integer.parseInt(maxTextFieldMod.getText()));
                        int i;
                        for (i = 0; i < Inventory.getAllParts().size(); i++) {
                            if (partToBeModifiedOutsourced.getId() == Inventory.getAllParts().get(i).getId()) {
                                Inventory.updatePart(i, partToBeModifiedOutsourced);
                            }
                        }
                    }
                    primaryStage.setScene(mainForm);
                }
            }
                catch(Exception exception){
                    errorLabelModifyPartForm.setText("Error: input not valid. Try again.");
                }
        });
        cancelButtonMod.setOnAction(e->primaryStage.setScene(mainForm));

        //Add product form
        saveNewProduct.setOnAction(e->{
            try {
                if (Integer.parseInt(minTextFieldProduct.getText()) > Integer.parseInt(maxTextFieldProduct.getText())) {
                    errorLabelAddProductForm.setText("Error: the minimum stock cannot be set greater than the maximum stock.");
                } else if (Integer.parseInt(invTextFieldProduct.getText()) < Integer.parseInt(minTextFieldProduct.getText())) {
                    errorLabelAddProductForm.setText("Error: current inventory level cannot be lower than the minimum stock");
                } else if (Integer.parseInt(invTextFieldProduct.getText()) > Integer.parseInt(maxTextFieldProduct.getText())) {
                    errorLabelAddProductForm.setText("Error: current inventory level cannot be higher than the maximum stock");
                } else {
                    Product newProduct = new Product(Integer.parseInt(idTextFieldProduct.getText()), nameTextFieldProduct.getText(), Double.parseDouble(priceCostTextFieldProduct.getText()),
                            Integer.parseInt(invTextFieldProduct.getText()), Integer.parseInt(minTextFieldProduct.getText()), Integer.parseInt(maxTextFieldProduct.getText()));
                    int i;
                    for (i = 0; i < associatedPartsList.size(); i++) {
                        newProduct.addAssociatedPart(associatedPartsList.get(i));
                    }
                    Inventory.addProduct(newProduct);
                    associatedParts.getItems().clear();
                    primaryStage.setScene(mainForm);
                }
            }
                catch(Exception exception){
                    errorLabelAddProductForm.setText("Error: input not valid. Try again.");
                }
        });
        cancelNewProduct.setOnAction(e->primaryStage.setScene(mainForm));

        //Modify product form
        saveNewProductMod.setOnAction(e-> {
            try {
                if (Integer.parseInt(minTextFieldProductMod.getText()) > Integer.parseInt(maxTextFieldProductMod.getText())) {
                    errorLabelModifyProductForm.setText("Error: the minimum stock cannot be set greater than the maximum stock.");
                } else if (Integer.parseInt(invTextFieldProductMod.getText()) < Integer.parseInt(minTextFieldProductMod.getText())) {
                    errorLabelModifyProductForm.setText("Error: current inventory level cannot be lower than the minimum stock");
                } else if (Integer.parseInt(invTextFieldProductMod.getText()) > Integer.parseInt(maxTextFieldProductMod.getText())) {
                    errorLabelModifyProductForm.setText("Error: current inventory level cannot be higher than the maximum stock");
                } else {
                    Product productToBeModified = new Product(Integer.parseInt(idTextFieldProductMod.getText()), nameTextFieldProductMod.getText(), Double.parseDouble(priceCostTextFieldProductMod.getText()), Integer.parseInt(invTextFieldProductMod.getText()), Integer.parseInt(minTextFieldProductMod.getText()), Integer.parseInt(maxTextFieldProductMod.getText()));
                    int i;
                    for (i = 0; i < Inventory.getAllProducts().size(); i++) {
                        if (productToBeModified.getId() == Inventory.getAllProducts().get(i).getId()) {
                            Inventory.updateProduct(i, productToBeModified);
                        }
                    }
                    primaryStage.setScene(mainForm);
                }
            }
                catch (Exception exception){
                    errorLabelModifyProductForm.setText("Error: input not valid. Try again.");
                }
        });
        cancelNewProductMod.setOnAction(e->primaryStage.setScene(mainForm));
        primaryStage.setScene(mainForm);
        primaryStage.show();
    }
}
